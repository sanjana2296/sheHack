import { useState, useEffect } from "react";
import axios from "axios";

// @mui material components
import Divider from "@mui/material/Divider";
import Icon from "@mui/material/Icon";

// Material Dashboard 2 React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import MDButton from "components/MDButton";

// Custom styles for the Configurator
import ConfiguratorRoot from "examples/Configurator/ConfiguratorRoot";

// Material Dashboard 2 React context
import { useMaterialUIController, setOpenConfigurator } from "context";

function Configurator() {
  const [controller, dispatch] = useMaterialUIController();
  const { openConfigurator, darkMode } = controller;
  const [selectedMood, setSelectedMood] = useState("");
  const [moodAnalysis, setMoodAnalysis] = useState(null);

  useEffect(() => {
    if (selectedMood) {
      fetchMoodAnalysis(selectedMood);
    }
  }, [selectedMood]);

  const fetchMoodAnalysis = async (mood) => {
    try {
      const response = await axios.post("https://your-backend-url.com/analyze-mood", { mood });
      setMoodAnalysis(response.data);
    } catch (error) {
      console.error("Error fetching mood analysis:", error);
    }
  };

  const handleCloseConfigurator = () => setOpenConfigurator(dispatch, false);

  return (
    <ConfiguratorRoot variant="permanent" ownerState={{ openConfigurator }}>
      <MDBox display="flex" justifyContent="space-between" alignItems="baseline" pt={4} pb={0.5} px={3}>
        <MDBox>
          <MDTypography variant="h5">Let's analyze your mood</MDTypography>
          <MDTypography variant="body2" color="text">See our dashboard options.</MDTypography>
        </MDBox>
        <Icon onClick={handleCloseConfigurator} sx={{ cursor: "pointer" }}>close</Icon>
      </MDBox>
      <Divider />
      <MDBox pt={0.5} pb={3} px={3}>
        <MDTypography variant="h6">How are you feeling today?</MDTypography>
        <MDBox display="flex" gap={1} mt={1}>
          <MDButton onClick={() => setSelectedMood("Happy")} variant="contained" color="success">Happy</MDButton>
          <MDButton onClick={() => setSelectedMood("Sad")} variant="contained" color="error">Sad</MDButton>
        </MDBox>
        {selectedMood && (
          <MDTypography variant="body2" color="text" mt={1}>You selected: {selectedMood}</MDTypography>
        )}
        {moodAnalysis && (
          <MDTypography variant="body2" color="text" mt={2}>Analysis: {moodAnalysis.message}</MDTypography>
        )}
        <Divider />
      </MDBox>
    </ConfiguratorRoot>
  );
}

export default Configurator;
